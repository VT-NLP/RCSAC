#!/usr/bin/env python
# coding: utf-8

# In[119]:


def html2csv(infile):
    import re
    import csv
    
    doc = open(infile).readlines()
    outfile=infile.split('.')[0]+'.csv'
    
    
    with open(outfile, 'w', newline='') as csvfile:
        spamwriter = csv.writer(csvfile, delimiter=',',quotechar='|')


        start=False
       
        for d in doc:
            
            #print(d,start)
            if d.startswith('<span class=\'blueBold\'>'):
                start=True
            
            if start==True and d.endswith('<br />\n'):
                
                try:
                    d=d.replace('<span class=\'blueBold\'>','')
                    d=d.replace('</span>','')
                    d=d.replace('<br />\n','')
                    
                    
                    if re.search("(?:\(|\[)(.{7,22})(?:\)|\])", d):
                        out=re.split("(?:\(|\[)(.{7,22})(?:\)|\])", d, maxsplit=1)
                        out[2]=out[2][2:]
                        out[2]=out[2].replace('<b>','')
                        out[2]=out[2].replace('</b>','')
                        out[2]=out[2].replace('<span class=\'code_c\'>','')
                        out[2]=out[2].replace('<i>','')
                        out[2]=out[2].replace('</i>','')
                        #print(out)
                        spamwriter.writerow(out)
                        
                     
                    else:
                        
                        out=d.split(': ',1)
                        out.insert(1,'')
                        
                        if re.search("\d{1,2}:\d{1,2}:\d{1,2}.{0,}?(?:PM|AM)", out[0]):
                            date = re.split("(\d{1,2}:\d{1,2}:\d{1,2}.{0,}?(?:PM|AM))", out[0], maxsplit=1)[1]
                            name = re.split("(\d{1,2}:\d{1,2}:\d{1,2}.{0,}?(?:PM|AM))", out[0], maxsplit=1)[2]
                            out[0] = name.strip()
                            out[1] = date
                            
                        if len(out) ==3 and out[0][0]!='<':
                            out[2]=out[2].replace('<b>','')
                            out[2]=out[2].replace('</b>','')
                            out[2]=out[2].replace('<span class=\'code_c\'>','')
                            out[2]=out[2].replace('<i>','')
                            out[2]=out[2].replace('</i>','')
                            # print(out)
                            spamwriter.writerow(out)
                except:
                    pass
        


# In[120]:


import os
for x in os.listdir():
    if x.endswith('htm'):
        # print(x)
        try:
            html2csv(x)
        except:
            print('error',x)

